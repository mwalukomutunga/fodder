import MainBody from '../Components/MainBody'
import FilterModel from '../Components/FilterModel'
export default function Home() {
  return (
    <>
        <MainBody/>
        <FilterModel/>
    </>
  )
}
